from playwright.sync_api import sync_playwright
import time
import random
import re
import json
import csv
import os
import base64
import subprocess
import threading
import queue
import urllib.request
from urllib.parse import urlparse, parse_qs
from datetime import datetime
from langdetect import detect, LangDetectException

escritorios = ["Studio Guilherme Torres", "Ar Arquitetos", "Fernanda Marques Arquitetura", "Matheus Farah e Manoel Maia Arquitetura", "Ana Luisa Prévide Arquitetura", "XOK Arquitetura", "Roberto Leme Arquitetos", "Studio del Valle Arquitetura", "Capoano", "Bruna Barbieri Arquitetura", "Comover Arquitetura Interiores", "Eduardo Zaccagni Arquitetura", "PAR Projetos", "WCA Arquitetura, Urbanismo & Sustentabilidade", "Morato Arquitetura", "Studio Marq Arquitetura", "Acrópole Arquitetura", "Arquitetura Oscar Ferreira", "Ideia Arquitetura e Consultoria Ambiental", "Cia de Arquitetura", "Hype Studio", "Mader Arquitetos", "Siga XGD", "NEON Arquitetura", "Crippa e Assis Arquitetura", "CIS Arquitetura e Sustentabilidade", "Tectônica Escritório de Arquitetura", "LZB Arquitetura", "Mescla Arquitetos", "Evurb Arquitetura", "Caramelo Arquitetos Associados", "BLOCO Arquitetos", "BORA Arquitetura", "Bia Arquitetura", "Pontual Arquitetos", "Prédios Arquitetura e Design", "ND STUDIO Arquitetura & Design", "Carlos Eduardo de Lacerda Arquitetura e Planejamento", "Robson Miler Arquitetura", "Casau Arquitetura", "Studio A Arquitetura de Interiores", "Studio 62 Arquitetura", "Collen Arquitetura", "Sariedine Arquitetura", "Nick Madalena & Arquitetos", "Studio do Arquiteto", "Spinelli & Camara Arquitetos Associados", "MMEB Arquitetos", "Trup Arquitetos", "Ideias & Projetos", "Giz Arquitetura e Engenharia", "PORO Arquitetura", "4R Arquitetura & Decoração", "3ARQ"]

MENSAGEM = "Opa, boa tarde! Tudo bem? Vi o Instagram de vocês e achei o trabalho muito interessante.Eu desenvolvo landing pages e sites profissionais para empresas que querem melhorar a apresentação da marca e gerar mais oportunidades online.Posso te mostrar uma ideia rápida de como isso poderia funcionar para vocês?"

CIDADES_VALIDAS = ["são paulo", "sao paulo", "sp", "-sp", "/sp", "rio de janeiro", "rj", "-rj", "/rj", "minas gerais", "belo horizonte", "mg", "-mg", "/mg", "uberlândia", "uberlandia", "distrito federal", "brasília", "brasilia", "df", "-df", "/df", "rio grande do sul", "porto alegre", "rs", "-rs", "/rs", "pernambuco", "recife", "pe", "-pe", "/pe", "bahia", "salvador", "ba", "-ba", "/ba", "paraná", "curitiba", "pr", "-pr", "/pr", "londrina", "espírito santo", "espirito santo", "vitória", "vitoria", "es", "-es", "/es", "goiás", "goias", "goiânia", "goiania", "go", "-go", "/go", "mato grosso", "cuiabá", "cuiaba", "mt", "-mt", "/mt", "mato grosso do sul", "campo grande", "ms", "-ms", "/ms", "amazonas", "manaus", "am", "-am", "/am", "ceará", "ceara", "fortaleza", "ce", "-ce", "/ce", "campinas", "ribeirão preto", "ribeirao preto"]

CIDADES_POR_ESTADO = {
    "SP": ["são paulo", "sao paulo", "sp", "-sp", "/sp", "campinas", "ribeirão preto", "ribeirao preto"],
    "RJ": ["rio de janeiro", "rj", "-rj", "/rj"],
    "MG": ["minas gerais", "belo horizonte", "mg", "-mg", "/mg", "uberlândia", "uberlandia"],
    "DF": ["distrito federal", "brasília", "brasilia", "df", "-df", "/df"],
    "RS": ["rio grande do sul", "porto alegre", "rs", "-rs", "/rs"],
    "PE": ["pernambuco", "recife", "pe", "-pe", "/pe"],
    "BA": ["bahia", "salvador", "ba", "-ba", "/ba"],
    "PR": ["paraná", "curitiba", "pr", "-pr", "/pr", "londrina"],
    "ES": ["espírito santo", "espirito santo", "vitória", "vitoria", "es", "-es", "/es"],
    "GO": ["goiás", "goias", "goiânia", "goiania", "go", "-go", "/go"],
    "MT": ["mato grosso", "cuiabá", "cuiaba", "mt", "-mt", "/mt"],
    "MS": ["mato grosso do sul", "campo grande", "ms", "-ms", "/ms"],
    "AM": ["amazonas", "manaus", "am", "-am", "/am"],
    "CE": ["ceará", "ceara", "fortaleza", "ce", "-ce", "/ce"],
}

ESTADO_POR_NOME = {
    "Studio Guilherme Torres": "SP", "Ar Arquitetos": "SP", "Fernanda Marques Arquitetura": "SP", "Matheus Farah e Manoel Maia Arquitetura": "SP", "Ana Luisa Prévide Arquitetura": "SP", "XOK Arquitetura": "SP", "Roberto Leme Arquitetos": "SP", "Studio del Valle Arquitetura": "SP", "Capoano": "SP", "Bruna Barbieri Arquitetura": "SP", "Comover Arquitetura Interiores": "SP", "Eduardo Zaccagni Arquitetura": "SP", "PAR Projetos": "SP", "WCA Arquitetura, Urbanismo & Sustentabilidade": "RJ", "Morato Arquitetura": "MG", "Studio Marq Arquitetura": "MG", "Acrópole Arquitetura": "MG", "Arquitetura Oscar Ferreira": "MG", "Ideia Arquitetura e Consultoria Ambiental": "MG", "Cia de Arquitetura": "MG", "Hype Studio": "RS", "Mader Arquitetos": "RS", "Siga XGD": "RS", "NEON Arquitetura": "RS", "Crippa e Assis Arquitetura": "PR", "CIS Arquitetura e Sustentabilidade": "PR", "Tectônica Escritório de Arquitetura": "PR", "LZB Arquitetura": "PR", "Mescla Arquitetos": "PR", "Evurb Arquitetura": "PR", "Caramelo Arquitetos Associados": "BA", "BLOCO Arquitetos": "DF", "BORA Arquitetura": "DF", "Bia Arquitetura": "DF", "Pontual Arquitetos": "PE", "Prédios Arquitetura e Design": "PE", "ND STUDIO Arquitetura & Design": "PE", "Carlos Eduardo de Lacerda Arquitetura e Planejamento": "ES", "Robson Miler Arquitetura": "ES", "Casau Arquitetura": "ES", "Studio A Arquitetura de Interiores": "GO", "Studio 62 Arquitetura": "GO", "Collen Arquitetura": "GO", "Sariedine Arquitetura": "GO", "Nick Madalena & Arquitetos": "GO", "Studio do Arquiteto": "MT", "Spinelli & Camara Arquitetos Associados": "MT", "MMEB Arquitetos": "MT", "Trup Arquitetos": "MS", "Ideias & Projetos": "AM", "Giz Arquitetura e Engenharia": "CE", "PORO Arquitetura": "CE", "4R Arquitetura & Decoração": "CE", "3ARQ": "CE",
}

SERVICOS_ESPERADOS = ["arquitetura", "arquiteto", "arquiteta", "projetos", "interiores", "urbanismo", "design de interiores"]

MINIMO_CRITERIOS = 2

TAMANHO_LOTE = 50
PAUSA_ENTRE_LOTES = 3600

ARQUIVO_CHECKPOINT = "checkpoint.json"
ARQUIVO_LOG = "execucao.log"
ARQUIVO_RESULTADOS = "resultados.csv"

CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
CHROME_USER_DATA_DIR = r"C:\chrome-debug-profile"
CHROME_DEBUG_PORT = 9222
CHROME_TENTATIVAS_MAX = 30
CHROME_INTERVALO_ESPERA = 2

# NOVO: tempo máximo (segundos) que o main espera pela reabertura em background
# antes de desistir e propagar erro pra fora.
TIMEOUT_RECUPERACAO_SESSAO = 180

# NOVO: guarda o processo do Chrome que NÓS abrimos, pra matar só ele
# (nunca use taskkill /IM chrome.exe puro — mataria qualquer Chrome do usuário)
_chrome_process = None
_chrome_process_lock = threading.Lock()


def log(mensagem):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    linha = f"[{timestamp}] {mensagem}"
    print(linha)
    with open(ARQUIVO_LOG, "a", encoding="utf-8") as f:
        f.write(linha + "\n")


def carregar_checkpoint():
    if os.path.exists(ARQUIVO_CHECKPOINT):
        with open(ARQUIVO_CHECKPOINT, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"processados": []}


def salvar_checkpoint(dados):
    with open(ARQUIVO_CHECKPOINT, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)


def inicializar_csv():
    if not os.path.exists(ARQUIVO_RESULTADOS):
        with open(ARQUIVO_RESULTADOS, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["nome", "status", "handle", "motivo", "timestamp"])


def registrar_resultado(nome, status, handle="", motivo=""):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(ARQUIVO_RESULTADOS, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([nome, status, handle, motivo, timestamp])


def normalizar(texto):
    return re.sub(r'[^a-z0-9]', '', texto.lower())


def decodificar_link_bing(href):
    if "bing.com/ck/a" not in href:
        return href
    parsed = urlparse(href)
    qs = parse_qs(parsed.query)
    if 'u' in qs:
        encoded = qs['u'][0]
        if encoded.startswith('a1'):
            encoded = encoded[2:]
        padding = '=' * (-len(encoded) % 4)
        try:
            decoded = base64.urlsafe_b64decode(encoded + padding).decode('utf-8', errors='ignore')
            return decoded
        except Exception:
            return None
    return None


# ======================================================================
# Chrome debug: abertura, checagem, e KILL SWITCH direcionado ao PID
# ======================================================================

def chrome_esta_aberto(porta=CHROME_DEBUG_PORT, timeout=2):
    try:
        with urllib.request.urlopen(f"http://localhost:{porta}/json/version", timeout=timeout):
            return True
    except Exception:
        return False


def abrir_chrome():
    """Abre o Chrome em modo debug e guarda o processo em _chrome_process,
    pra podermos matar EXATAMENTE esse processo depois (kill switch), nunca
    qualquer chrome.exe que esteja rodando na máquina."""
    global _chrome_process
    log("Abrindo o Chrome em modo debug...")
    comando = [
        CHROME_PATH,
        f"--remote-debugging-port={CHROME_DEBUG_PORT}",
        f'--user-data-dir={CHROME_USER_DATA_DIR}',
    ]
    with _chrome_process_lock:
        _chrome_process = subprocess.Popen(
            comando,
            creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
            close_fds=True,
        )


def matar_chrome_debug():
    """KILL SWITCH: fecha especificamente o processo do Chrome que NÓS
    abrimos (via PID + /T pra matar a árvore de processos filhos também).
    Se não temos o PID (ex: script reiniciou e o Chrome já estava aberto
    de uma execução anterior), cai pra matar por porta/linha de comando
    seria arriscado, então nesse caso só loga e segue — deixamos o
    abrir_chrome() de qualquer forma reabrir uma instância nova."""
    global _chrome_process
    with _chrome_process_lock:
        proc = _chrome_process
    if proc is None or proc.poll() is not None:
        log("   Kill switch: nenhum processo Chrome rastreado (ou já finalizado). Pulando kill explícito.")
        return
    try:
        log(f"   Kill switch: encerrando Chrome (PID {proc.pid}) e seus processos filhos...")
        subprocess.run(
            ["taskkill", "/F", "/PID", str(proc.pid), "/T"],
            capture_output=True, timeout=15
        )
    except Exception as e:
        log(f"   Kill switch: falha ao matar PID {proc.pid}: {e}")
    finally:
        with _chrome_process_lock:
            _chrome_process = None


def garantir_chrome_aberto():
    if chrome_esta_aberto():
        return
    abrir_chrome()
    for tentativa in range(1, CHROME_TENTATIVAS_MAX + 1):
        time.sleep(CHROME_INTERVALO_ESPERA)
        if chrome_esta_aberto():
            log(f"Chrome pronto (respondeu na porta {CHROME_DEBUG_PORT} após {tentativa} tentativa(s)).")
            return
    raise RuntimeError(
        f"O Chrome não respondeu na porta {CHROME_DEBUG_PORT} depois de "
        f"{CHROME_TENTATIVAS_MAX * CHROME_INTERVALO_ESPERA}s."
    )


def conectar_navegador(p):
    garantir_chrome_aberto()
    browser = p.chromium.connect_over_cdp(f"http://localhost:{CHROME_DEBUG_PORT}")
    context = browser.contexts[0] if browser.contexts else browser.new_context()
    page = context.pages[0] if context.pages else context.new_page()
    return browser, context, page


def eh_erro_de_conexao(excecao):
    msg = str(excecao).lower()
    termos = ["econnrefused", "target closed", "connection closed",
              "websocket", "browser has been closed", "disconnected"]
    return any(t in msg for t in termos)


# ======================================================================
# NOVO: recuperação da sessão em thread separada (auxiliar), sem travar
# o main de forma "cega" — ele fica logando/aguardando com timeout.
# ======================================================================

def _trabalho_auxiliar_reabrir(resultado_queue):
    """Roda em thread separada: mata o Chrome atual (kill switch) e o
    reabre do zero. Não recria o objeto Playwright/browser aqui porque
    connect_over_cdp precisa rodar no mesmo `p` (sync_playwright context)
    usado pelo main — então essa thread só cuida da parte que pode ser
    feita fora do laço principal: matar + relançar o processo do Chrome
    e esperar a porta de debug responder de novo."""
    try:
        matar_chrome_debug()
        time.sleep(2)
        garantir_chrome_aberto()
        resultado_queue.put(("ok", None))
    except Exception as e:
        resultado_queue.put(("erro", e))


def recuperar_sessao(p):
    """Dispara a reabertura do Chrome em background (thread auxiliar) e,
    enquanto isso, o main não fica travado silenciosamente: fica em loop
    curto de polling, logando periodicamente, até a thread confirmar que
    terminou (ou até estourar o timeout). Ao final, reconecta o Playwright
    (isso precisa ser feito na thread principal) e devolve
    (browser, context, page) novos."""
    log("   Sessão caiu. Disparando reabertura em segundo plano (thread auxiliar)...")
    resultado_queue = queue.Queue()
    thread_aux = threading.Thread(target=_trabalho_auxiliar_reabrir, args=(resultado_queue,), daemon=True)
    thread_aux.start()

    inicio = time.time()
    while thread_aux.is_alive():
        if time.time() - inicio > TIMEOUT_RECUPERACAO_SESSAO:
            raise RuntimeError(
                f"Reabertura do Chrome não terminou em {TIMEOUT_RECUPERACAO_SESSAO}s. Abortando."
            )
        log("   ...ainda aguardando o Chrome voltar (thread auxiliar rodando, main seguindo vivo)")
        time.sleep(5)

    status, erro = resultado_queue.get()
    if status == "erro":
        raise RuntimeError(f"Thread auxiliar falhou ao reabrir o Chrome: {erro}")

    log("   Thread auxiliar confirmou: Chrome de volta no ar. Reconectando o Playwright...")
    browser, context, page = conectar_navegador(p)
    log("   Sessão totalmente recuperada.")
    return browser, context, page


def buscar_link_instagram(page, nome):
    query = f"{nome} arquitetura instagram"
    page.goto(f"https://www.bing.com/search?q={query.replace(' ', '+')}")
    page.wait_for_timeout(2500)

    links = page.locator("a").all()
    for link in links:
        try:
            href = link.get_attribute("href")
        except Exception:
            continue
        if not href:
            continue
        href_real = decodificar_link_bing(href)
        if href_real and "instagram.com" in href_real:
            match = re.search(r"instagram\.com/([^&/?]+)", href_real)
            if match and match.group(1) not in ("p", "explore", "accounts", "reel"):
                return f"https://www.instagram.com/{match.group(1)}/"
    return None


def extrair_dados_perfil(page, url_instagram):
    page.goto(url_instagram)
    page.wait_for_timeout(3000)
    handle = url_instagram.rstrip('/').split('/')[-1]
    texto_header = ""
    try:
        texto_header = page.locator("header").inner_text(timeout=5000)
    except Exception:
        pass
    return handle, texto_header


def validar_perfil(nome_busca, handle, texto_header):
    criterios_batidos = []
    texto_lower = texto_header.lower()

    nome_norm = normalizar(nome_busca)
    handle_norm = normalizar(handle)
    if len(nome_norm) >= 4 and (nome_norm[:5] in handle_norm or handle_norm in nome_norm):
        criterios_batidos.append("handle")

    palavras_busca = [p for p in re.split(r'\W+', nome_busca.lower()) if len(p) >= 4]
    if any(p in texto_lower for p in palavras_busca):
        criterios_batidos.append("nome_exibido")

    estado = ESTADO_POR_NOME.get(nome_busca)
    cidades_para_checar = CIDADES_POR_ESTADO[estado] if estado else CIDADES_VALIDAS
    if any(cidade in texto_lower for cidade in cidades_para_checar):
        criterios_batidos.append("cidade")

    if any(servico in texto_lower for servico in SERVICOS_ESPERADOS):
        criterios_batidos.append("servico")

    idioma_ok = True
    if texto_header.strip():
        try:
            idioma = detect(texto_header)
            if idioma != "pt":
                idioma_ok = False
        except LangDetectException:
            pass

    return criterios_batidos, idioma_ok


def enviar_mensagem_playwright(page):
    try:
        botao = page.get_by_role("button", name="Enviar mensagem")
        botao.click(timeout=5000)
        page.wait_for_timeout(1500)
        campo_texto = page.get_by_role("textbox").last
        campo_texto.click(timeout=5000)
        campo_texto.fill(MENSAGEM)
        page.wait_for_timeout(500)
        campo_texto.press("Enter")
        page.wait_for_timeout(1500)
        trecho_busca = MENSAGEM[:30]
        conteudo_pagina = page.locator("body").inner_text(timeout=3000)
        return trecho_busca in conteudo_pagina
    except Exception as e:
        log(f"   Erro ao enviar via Playwright: {e}")
        return False


# NOVO: wrapper genérico que executa qualquer etapa da página e, se a
# sessão cair no meio, aciona recuperar_sessao() e refaz a MESMA etapa
# (em vez de perder o nome atual e pular pro próximo).
def com_recuperacao(p, funcao, *args, max_tentativas=2, **kwargs):
    global browser, context, page
    for tentativa in range(1, max_tentativas + 1):
        try:
            return funcao(*args, **kwargs)
        except Exception as e:
            if eh_erro_de_conexao(e) and tentativa < max_tentativas:
                log(f"   Erro de conexão em '{funcao.__name__}': {e}")
                browser, context, page = recuperar_sessao(p)
                # se a função usava 'page' como primeiro argumento, atualiza
                if args and args[0] is not page:
                    args = (page,) + args[1:]
                continue
            raise


# ============ EXECUÇÃO PRINCIPAL ============
inicializar_csv()
checkpoint = carregar_checkpoint()
ja_processados = set(checkpoint["processados"])

pendentes = [nome for nome in escritorios if nome not in ja_processados]

log(f"=== INÍCIO DA EXECUÇÃO ===")
log(f"Total na lista: {len(escritorios)} | Já processados antes: {len(ja_processados)} | Pendentes agora: {len(pendentes)}")

if not pendentes:
    log("Todos os nomes já foram processados anteriormente. Nada a fazer.")
    log(f"Confira os resultados completos em: {ARQUIVO_RESULTADOS}")
else:
    with sync_playwright() as p:
        browser, context, page = conectar_navegador(p)

        for i, nome in enumerate(pendentes, start=1):
            try:
                link = com_recuperacao(p, buscar_link_instagram, page, nome)
                if link is None:
                    log(f"⚠ ({i}/{len(pendentes)}) Sem link do Instagram: {nome}")
                    registrar_resultado(nome, "revisao_manual", motivo="sem link encontrado no Bing")
                    checkpoint["processados"].append(nome)
                    salvar_checkpoint(checkpoint)
                    time.sleep(random.randint(6, 12))
                    continue

                handle, texto_header = com_recuperacao(p, extrair_dados_perfil, page, link)
                criterios, idioma_ok = validar_perfil(nome, handle, texto_header)

                log(f"   → {nome} | @{handle} | critérios: {criterios} | idioma_ok: {idioma_ok}")

                if not idioma_ok:
                    log(f"⚠ ({i}/{len(pendentes)}) Bio não está em português: {nome}")
                    registrar_resultado(nome, "revisao_manual", handle, "idioma não-pt")
                    checkpoint["processados"].append(nome)
                    salvar_checkpoint(checkpoint)
                    time.sleep(random.randint(6, 12))
                    continue

                if len(criterios) < MINIMO_CRITERIOS:
                    log(f"⚠ ({i}/{len(pendentes)}) Critérios insuficientes ({len(criterios)}/4): {nome}")
                    registrar_resultado(nome, "revisao_manual", handle, f"apenas {criterios} batido(s)")
                    checkpoint["processados"].append(nome)
                    salvar_checkpoint(checkpoint)
                    time.sleep(random.randint(6, 12))
                    continue

                enviado = com_recuperacao(p, enviar_mensagem_playwright, page)
                if not enviado:
                    log(f"⚠ ({i}/{len(pendentes)}) Mensagem NÃO confirmada no chat: {nome}")
                    registrar_resultado(nome, "revisao_manual", handle, "envio não confirmado")
                else:
                    log(f"✔ ({i}/{len(pendentes)}) Mensagem enviada e confirmada: {nome} (@{handle})")
                    registrar_resultado(nome, "enviado", handle)

                checkpoint["processados"].append(nome)
                salvar_checkpoint(checkpoint)

            except Exception as e:
                log(f"✘ Falhou em: {nome} | Erro: {e}")
                registrar_resultado(nome, "erro_tecnico", motivo=str(e))
                checkpoint["processados"].append(nome)
                salvar_checkpoint(checkpoint)

                if eh_erro_de_conexao(e):
                    log("   Erro de conexão não recuperado pelo wrapper. Tentando recuperar sessão antes de seguir...")
                    try:
                        browser, context, page = recuperar_sessao(p)
                        log("   Reconectado com sucesso.")
                    except Exception as e2:
                        log(f"   Falha ao recuperar sessão: {e2}. Abortando execução.")
                        raise

            eh_ultimo = (i == len(pendentes))

            if not eh_ultimo and i % TAMANHO_LOTE == 0:
                log(f"⏸⏸ Fim do lote de {TAMANHO_LOTE}. Pausa longa de {PAUSA_ENTRE_LOTES // 60} min antes do próximo lote...")
                time.sleep(PAUSA_ENTRE_LOTES)
                browser, context, page = conectar_navegador(p)
            elif not eh_ultimo and i % 30 == 0:
                pausa_bloco = random.randint(900, 1500)
                log(f"⏸ Pausa de bloco: {pausa_bloco // 60} min")
                time.sleep(pausa_bloco)
                browser, context, page = conectar_navegador(p)
            elif not eh_ultimo:
                time.sleep(random.randint(85, 100))

    log("=== FIM DA EXECUÇÃO ===")
    log(f"Confira os resultados completos em: {ARQUIVO_RESULTADOS}")
    log(f"Log completo desta e de execuções anteriores em: {ARQUIVO_LOG}")