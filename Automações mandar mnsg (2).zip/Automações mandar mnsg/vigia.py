import subprocess
import time
from datetime import datetime

NOME_SCRIPT = "main.py"
MAX_TENTATIVAS = 50  # limite de segurança, pra não reiniciar infinitamente se algo estiver muito quebrado


def log_vigia(mensagem):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    linha = f"[{timestamp}] [VIGIA] {mensagem}"
    print(linha)
    with open("vigia.log", "a", encoding="utf-8") as f:
        f.write(linha + "\n")


tentativa = 0

while tentativa < MAX_TENTATIVAS:
    tentativa += 1
    log_vigia(f"Iniciando {NOME_SCRIPT} (tentativa {tentativa}/{MAX_TENTATIVAS})...")

    processo = subprocess.run(["python", NOME_SCRIPT])

    if processo.returncode == 0:
        log_vigia(f"{NOME_SCRIPT} terminou normalmente (código 0). Encerrando o vigia.")
        break
    else:
        log_vigia(f"{NOME_SCRIPT} encerrou com erro (código {processo.returncode}). Reiniciando em 30s...")
        time.sleep(30)  # pequena pausa antes de tentar de novo, evita loop de crash instantâneo

else:
    log_vigia(f"Limite de {MAX_TENTATIVAS} tentativas atingido. Parando o vigia — verifique manualmente o que está acontecendo.")